import json

DataACC = {}
data = {("TIMER_INI" ): str(1010)}
DataACC.update(data)
print(DataACC)

data = {("ACCx" ): str(77777)}
DataACC.update(data)

data = {("ACCY" ): str(0000)}

str_do_file =  json.dumps(DataACC)+ ","+ json.dumps(data)

data = {("ACCZ" ): str(1111)}

str_do_file = str_do_file + ","+  json.dumps(data)

print(str_do_file)

print(str_do_file.split(","))