from flask import Flask, request, jsonify
import psycopg2
app = Flask(__name__)

def insert(lote, AccX,AccY,AccZ):
    try:
        connection = psycopg2.connect(user="postgres",
                                      password="785623",
                                      host="127.0.0.1",
                                      port="5432",
                                      database="data_amostra")
        cursor = connection.cursor()

        postgres_insert_query = """INSERT INTO amostra_t (lote,accx,accy,accz) VALUES (%s,%s,%s,%s)"""
        record_to_insert = (lote, AccX, AccY, AccZ)
        cursor.execute(postgres_insert_query, record_to_insert)

        connection.commit()
        count = cursor.rowcount
        print(count, "Record inserted successfully into amostra_t table")

    except (Exception, psycopg2.Error) as error:
        print("Failed to insert record into amostra_t table", error)

    finally:
        # closing database connection.
        if connection:
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")



def bulkInsert(records):
    try:
        connection = psycopg2.connect(user="postgres",
                                      password="785623",
                                      host="127.0.0.1",
                                      port="5432",
                                      database="data_amostra")
        cursor = connection.cursor()
        sql_insert_query = """ INSERT INTO amostra_t (id, model, price) 
                           VALUES (%s,%s,%s) """

        # executemany() to insert multiple rows
        result = cursor.executemany(sql_insert_query, records)
        connection.commit()
        print(cursor.rowcount, "Record inserted successfully into amostra_t table")

    except (Exception, psycopg2.Error) as error:
        print("Failed inserting record into amostra_t table {}".format(error))

    finally:
        # closing database connection.
        if connection:
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")




def updateTable(amostra_tId, price):
    try:
        connection = psycopg2.connect(user="postgres",
                                      password="pynative@#29",
                                      host="127.0.0.1",
                                      port="5432",
                                      database="data_amostra")

        cursor = connection.cursor()

        print("Table Before updating record ")
        sql_select_query = """select * from amostra_t where id = %s"""
        cursor.execute(sql_select_query, (amostra_tId,))
        record = cursor.fetchone()
        print(record)

        # Update single record now
        sql_update_query = """Update amostra_t set price = %s where id = %s"""
        cursor.execute(sql_update_query, (price, amostra_tId))
        connection.commit()
        count = cursor.rowcount
        print(count, "Record Updated successfully ")

        print("Table After updating record ")
        sql_select_query = """select * from amostra_t where id = %s"""
        cursor.execute(sql_select_query, (amostra_tId,))
        record = cursor.fetchone()
        print(record)

    except (Exception, psycopg2.Error) as error:
        print("Error in update operation", error)

    finally:
        # closing database connection.
        if connection:
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")




def deleteData(amostra_tId):
    try:
        connection = psycopg2.connect(user="postgres",
                                      password="pynative@#29",
                                      host="127.0.0.1",
                                      port="5432",
                                      database="data_amostra")

        cursor = connection.cursor()

        # Update single record now
        sql_delete_query = """Delete from amostra_t where id = %s"""
        cursor.execute(sql_delete_query, (amostra_tId,))
        connection.commit()
        count = cursor.rowcount
        print(count, "Record deleted successfully ")

    except (Exception, psycopg2.Error) as error:
        print("Error in Delete operation", error)

    finally:
        # closing database connection.
        if connection:
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")

@app.route("/")
def hello():
    return "Hello Worlllllaaaaaaaaaaaaad! t"

@app.route('/envio', methods=['POST'])
def webhook():
    data = request.get_json(force=True)
    v_key = sorted(list(data))
    print(v_key)
    N_items = 4

    print("Entrou")

    for conjunto in range(0, len(data), N_items):
        print(conjunto)
        insert( data[v_key[0]], data[v_key[conjunto + 1]], data[v_key[conjunto + 2]], data[v_key[conjunto + 3]] )


    return "OK", 200

if __name__ == '__main__':

    app.run("0.0.0.0", 3040, debug = True)
