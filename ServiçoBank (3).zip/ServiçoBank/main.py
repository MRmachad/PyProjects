from flask import Flask, request, jsonify
from bibs.bd import BD
from bibs.hold import Holder

app = Flask(__name__)

bd = BD()
hold = Holder()

@app.route("/")
def hello():
    return "<h1>Hello Worlllllaaaaaaaaaaasdfafaaad! </h1>"

@app.route('/envio', methods=['POST'])
def webhook():

    data = request.get_json(force=True)
    v_key = sorted(list(data))
    print(v_key)


    if "0A_ID_ESP" in v_key:

        hold.setDateID(data[v_key[0]], data[v_key[1]], data[v_key[2]], 170)
        v_key.pop(0)
        v_key.pop(0)
        v_key.pop(0)

    accX, accY, accZ = [], [], []
    for i in range(0, len(v_key), 3):

        accX.append(data[v_key[i]])
        accY.append(data[v_key[i + 1]])
        accZ.append(data[v_key[i + 2]])

    print("Tamanho dos vetores antes do envio:: ", accX,", ", accY,", ", accZ,"\n\n" )
    bd.InsertMuitas(hold.juntalinhas(accX,accY,accZ))


    return "OK", 200

if __name__ == '__main__':

    app.run("0.0.0.0", 3050, debug = True)
