import os
import replaceTag
if __name__ == '__main__':

    Vdir = []
    pasta = './displays'

    for diretorio, subpastas, arquivos in os.walk(pasta):
        for arquivo in arquivos:
            Vdir.append(os.path.join(diretorio, arquivo))

    print(Vdir)

    ob = replaceTag.ReplaceTag("DP-Tags", Vdir)
    ob.percor()

    ob2 = replaceTag.ReplaceTag("DP-Tags-CIP3", Vdir)

    ob2.percor()