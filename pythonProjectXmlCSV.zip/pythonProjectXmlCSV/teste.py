if __name__ == '__main__':
    teste =  ["a", "a", "a", "b"]
    print(teste)

    while "a" in teste:
        teste.remove("a")

    print(teste)
    b = ["ab_man", "cb_man", "cb_rh_man", "abman_hf"]

    v = ["a.0", "d.1", "c.2", "simples"]

    print(len(b))
    print(len(v))

    """ eperado:

    bSaida = ["ab_", "cb_", "cb_rh_", "abman_"]
    vSaida = ["a.", "d.", "c.", "ab.", "simples"],

    """

    vSaida = []
    bSaida = []

    for idx in range(len(b)):

        texto_1 = ""
        texto_2 = ""

        auxIdx = b[idx].rfind("_")

        if auxIdx >= 0:

            for cont in range(auxIdx + 1):
                texto_1 += (b[idx][cont])
                print(texto_1 + "\n")

            bSaida.append(texto_1)

            auxIdx = v[idx].find(".")

            if auxIdx >= 0:

                for cont in range(auxIdx + 1):
                    texto_2 += (v[idx][cont])
                    print(texto_2 + "\n")

                vSaida.append(texto_2)

            else:
                vSaida.append(v[idx])

        else:
            pass

    print(bSaida)
    print(vSaida)

