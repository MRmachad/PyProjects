from numpy import NaN
import pandas as pd
import regex as re
from pandas import DataFrame


class ReplaceTag:
    def __init__(self, nomeCsv="DP-Tags", VstrDisplays=[]):
        print("instanciada\n")

        self.auxNome = nomeCsv + ".xlsm"
        self.auxTbTag = []
        self.auxTbNode = []
        self.auxTbAdress = []

        self.tbTag = self.column_of_csv(" Tag Name").tolist()
        # print(self.tbTag)
        # print("\n")

        self.tbNode = self.column_of_csv(" Node Name").tolist()
        # print(self.tbNode)
        # print("\n")

        self.tbAdress = self.column_of_csv(" Address").tolist()
        # print(self.tbAdress)
        # print("\n")

        self.verificaComum()

        #
        print("carregamento de dados de Tabela completo\n")
        #

        self.VstrDisplays = VstrDisplays

    def limpaNAN(self):

        while NaN in ((self.tbTag) and (self.tbNode) and (self.tbAdress)):
            for idx in range(len(self.tbTag)):
                if pd.isna(self.tbTag[idx]) or pd.isna(self.tbNode[idx]) or pd.isna(self.tbAdress[idx]):
                    self.tbTag.pop(idx)
                    self.tbNode.pop(idx)
                    self.tbAdress.pop(idx)
                    break


    def verificaComum(self):

        print(len(self.tbTag))
        print(len(self.tbNode))
        print(len(self.tbAdress))
        print("\n")

        self.limpaNAN()

        for idx1 in range(len(self.tbTag)):
            for idx2 in range(len(self.tbTag)):
                if str(self.tbTag[idx1]) in str(self.tbTag[idx2]):
                    if (idx1 != idx2):
                        self.auxTbTag.append(self.tbTag[idx1])
                        self.auxTbNode.append(self.tbNode[idx1])
                        self.auxTbAdress.append(self.tbAdress[idx1])
                        self.tbTag[idx1] = "*00000*"
                        self.tbNode[idx1] = "*00000*"
                        self.tbAdress[idx1] = "*00000*"
                        break

        print(len(self.tbTag))
        print(len(self.tbNode))
        print(len(self.tbAdress))
        print("\n")

        while "*00000*" in self.tbTag:
            self.tbTag.remove("*00000*")
            self.tbNode.remove("*00000*")
            self.tbAdress.remove("*00000*")

        print(len(self.tbTag))
        print(len(self.tbNode))
        print(len(self.tbAdress))
        print("\n")

        for idx in range(len(self.auxTbTag)):
            self.tbTag.append(self.auxTbTag[idx])
            self.tbNode.append(self.auxTbNode[idx])
            self.tbAdress.append(self.auxTbAdress[idx])

        print(len(self.tbTag))
        print(len(self.tbNode))
        print(len(self.tbAdress))
        print("\n")

    def column_of_csv(self, column):

        reader = pd.read_excel(self.auxNome)

        auxV = reader[column].loc[0:len(reader)]
        return auxV

    def percor(self):

        for xml in self.VstrDisplays:
            print("No display " + xml + "\n \n \n \n \n \n")
            auxXML = open(xml, "r+", encoding = 'cp850')
            textoXML = str("".join(auxXML.readlines()))


            for idx in range(len(self.tbTag)):

                if str(self.tbTag[idx]).lower() in textoXML.lower():

                    apontamentoC = "{[" + self.tbNode[idx] + "]" + self.tbAdress[idx] + "}"

                    src_str = re.compile(re.escape("{" + str(self.tbTag[idx]) + "}"), re.IGNORECASE)
                    textoXML = src_str.sub(apontamentoC, textoXML)

                    src_str = re.compile(re.escape(str(self.tbTag[idx])), re.IGNORECASE)
                    textoXML = src_str.sub(apontamentoC, textoXML)

                    print("REPLACE:  " + self.tbTag[idx] + " --> " + apontamentoC + "\n")

                else:
                    pass

            print("\n \n \n \n \n \n" + "Busca por replace encerrada" + "\n \n \n \n \n \n")

            auxXML.seek(0)
            auxXML.write(textoXML)
            auxXML.truncate()
            auxXML.close()

        print(len(self.tbTag))
        print(len(self.tbNode))
        print(len(self.tbAdress))